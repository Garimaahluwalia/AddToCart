export const environment = {
    production: false,
    Productapiurl: 'https://dummyjson.com/products',


};
