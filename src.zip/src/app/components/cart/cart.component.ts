import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CartService } from '../../services/cart.service';
import { BehaviorSubject } from 'rxjs';
import { QuantityComponent } from '../quantity/quantity.component';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public cartItems: any[] = [];
  clear: any[] | undefined;
  public subTotalAmount: number = 0;
  public subTotalAmountQuantity: any;
  @ViewChild(QuantityComponent, { static: true }) quantityComponent: QuantityComponent | undefined;

  constructor(public cartservice: CartService, public route: Router, public router: ActivatedRoute) { }
  ngOnInit() {

    console.log(this.quantityComponent?.inputnumber);
    this.cartItems = this.cartservice.cart()
    this.subTotalAmount = this.cartservice.getSubTotalAmount();

  }


  clearCart() {
    this.cartItems.splice(0)
    this.subTotalAmount = this.cartservice.getSubTotalAmount();


  }
  
  removeItem(i: any) {
    this.cartItems.splice(i, 1);
    // this.cartservice.refreshCartItems.emit({event_name:"remove"});

    this.subTotalAmount = this.cartservice.getSubTotalAmount();

  }


}
