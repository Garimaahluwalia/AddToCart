import { EventEmitter, Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { IProducts } from '../interface';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private CartProduct: IProducts[] = []
  public AddtoCartEvent = new BehaviorSubject<number>(0);
  public refreshCartItems: EventEmitter<any> = new EventEmitter();




  removedData: any;


  constructor() {
    this.refreshCartItems.subscribe(({ event_name }) => {
      if (event_name == 'remove') {
        this.getSubTotalAmount();
      }
    })
  }




  cart() {
    return this.CartProduct
  }


  getSubTotalAmount() {
    return this.CartProduct.reduce((Subtotal, cartItems) => {
      return Subtotal + cartItems.price - (cartItems.price / 100 * cartItems.discountPercentage) * 1 
    }, 0);
  }

  clearCart() {
    this.CartProduct = []
  }

  addProduct(productid: number, product: IProducts) {
    this.CartProduct.push(product);
    this.AddtoCartEvent.next(this.CartProduct.length);
  }


  getProduct() {
    return this.CartProduct;
  }


  checkIfProductExistsInCart(productId: number): boolean {
    let v = this.CartProduct.find(v => v.id === productId)
    // console.log(v, !v, !!v, this.CartProduct, !null, !undefined, !true)
    return !!v
  }


  removeProduct(productid: number, product: IProducts) {
    if (this.CartProduct !== null) {
      // this.removedData = this.CartProduct.filter(v => v.id === productid).splice(0, 1)
      const index = this.CartProduct.findIndex(v => v.id == productid)
      this.CartProduct.splice(index, 1)
    }
    this.AddtoCartEvent.next(this.CartProduct.length)
  }
 


}




